/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign2;

import java.util.ArrayList;

/**
 *
 * @author Shanty
 */
public class clubs {
private ArrayList <Person> Clubforshortraces; 
private ArrayList <Person> Clubforlongrace;


 public clubs(){
    Clubforshortraces=new ArrayList <>();
    Clubforlongrace=new ArrayList <>();
   
}

    public ArrayList<Person> getClubforshortraces() {
        return Clubforshortraces;
    }

    public ArrayList<Person> getClubforlongrace() {
        return Clubforlongrace;
    }


public void addathleteforshortraces(Person athlete){
    if(athlete.getBesttime100m() > 11.32 || athlete.getBesttime200m()  < 22) {
        Clubforshortraces.add(athlete);
    }
}
public void addathleteforlongraces(Person athlete){
    if(athlete.getBesttime5km()<1200) {
        Clubforlongrace.add(athlete);
    }
}



}
